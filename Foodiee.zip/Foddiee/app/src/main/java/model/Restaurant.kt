package model

data class Restaurant (
    var restaurantId:String,
    var restaurantName:String,
    var restaurantRating:String,
    var cost_for_one:String,
    var restaurantImage:String
)
