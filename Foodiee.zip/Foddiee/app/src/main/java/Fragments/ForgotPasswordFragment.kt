package Fragments

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.RelativeLayout
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.arjun.foddiee.R
import org.json.JSONException
import org.json.JSONObject
import util.ConnectionManager

class ForgotPasswordFragment(val contextParam: Context, val mobileNumber: String) : Fragment() {

    lateinit var OTP: EditText
    lateinit var NewPassword: EditText
    lateinit var ConfirmPassword: EditText
    lateinit var forgotPasswordLayout: RelativeLayout
    lateinit var btnSubmit: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_forgot_password, container, false)

        OTP = view.findViewById(R.id.OTP)
        NewPassword = view.findViewById(R.id.NewPassword)
        ConfirmPassword = view.findViewById(R.id.ConfirmPassword)
        btnSubmit = view.findViewById(R.id.btnSubmit)
        forgotPasswordLayout = view.findViewById(R.id.forgotPasswordLayout)

        btnSubmit.setOnClickListener {
            if (OTP.text.isBlank()) {
                OTP.error = "OTP missing"
            } else {
                if (NewPassword.text.isBlank() || NewPassword.text.length <= 4) {
                    NewPassword.error = "Invalid Password"
                } else {
                    if (ConfirmPassword.text.isBlank()) {
                        ConfirmPassword.error = "Confirm Password Missing"
                    } else {
                        if ((NewPassword.text.toString().toInt() == ConfirmPassword.text.toString().toInt())
                        ) {
                            if (ConnectionManager().checkConnectivity(activity as Context)) {

                                forgotPasswordLayout.visibility = View.VISIBLE

                                try {

                                    val loginUser = JSONObject()
                                    loginUser.put("mobile_number", mobileNumber)
                                    loginUser.put("password", NewPassword.text.toString())
                                    loginUser.put("otp", OTP.text.toString())

                                    val queue = Volley.newRequestQueue(activity as Context)
                                    val url = "http://13.235.250.119/v2/reset_password/fetch_result"

                                    val jsonObjectRequest = object : JsonObjectRequest(
                                        Method.POST,
                                        url,
                                        loginUser,
                                        Response.Listener {

                                            val response = it.getJSONObject("data")
                                            val success = response.getBoolean("success")

                                            if (success) {
                                                val serverMessage = response.getString("successMessage")

                                                Toast.makeText(contextParam, serverMessage, Toast.LENGTH_SHORT).show()

                                                passwordChanged()

                                            } else {
                                                val responseMessageServer =
                                                    response.getString("errorMessage")
                                                Toast.makeText(contextParam, responseMessageServer.toString(), Toast.LENGTH_SHORT).show()

                                            }
                                            forgotPasswordLayout.visibility = View.INVISIBLE
                                        },
                                        Response.ErrorListener {

                                            forgotPasswordLayout.visibility = View.INVISIBLE

                                            Toast.makeText(contextParam, "Some Error occurred!!!", Toast.LENGTH_SHORT).show()

                                        }) {
                                        override fun getHeaders(): MutableMap<String, String> {
                                            val headers = HashMap<String, String>()
                                            headers["Content-type"] = "application/json"
                                            headers["token"] = "2540cc341e3cb1"
                                            return headers
                                        }
                                    }

                                    queue.add(jsonObjectRequest)

                                } catch (e: JSONException) {
                                    Toast.makeText(contextParam, "Some unexpected error occurred!!!", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                val alterDialog = androidx.appcompat.app.AlertDialog.Builder(activity as Context)
                                alterDialog.setTitle("No Internet")
                                alterDialog.setMessage("Check Internet Connection!")
                                alterDialog.setPositiveButton("Open Settings") { _, _ ->
                                    val settingsIntent = Intent(Settings.ACTION_SETTINGS)
                                    startActivity(settingsIntent)
                                }
                                alterDialog.setNegativeButton("Exit") { _, _ ->
                                    ActivityCompat.finishAffinity(activity as Activity)
                                }
                                alterDialog.create()
                                alterDialog.show()
                            }

                        } else {
                            ConfirmPassword.error = "Passwords don't match"
                        }
                    }
                }
            }
        }
        return view
    }

    fun passwordChanged() {
        val transaction = fragmentManager?.beginTransaction()
        transaction?.replace(
            R.id.frameLayout,
            LoginFragment(contextParam)
        )

        transaction?.commit()
    }

    override fun onResume() {

        if (!ConnectionManager().checkConnectivity(activity as Context)) {

            val alterDialog = androidx.appcompat.app.AlertDialog.Builder(activity as Context)
            alterDialog.setTitle("No Internet")
            alterDialog.setMessage("Check Internet Connection!")
            alterDialog.setPositiveButton("Open Settings") { _, _ ->
                val settingsIntent = Intent(Settings.ACTION_SETTINGS)
                startActivity(settingsIntent)
            }
            alterDialog.setNegativeButton("Exit") { _, _ ->
                ActivityCompat.finishAffinity(activity as Activity)
            }
            alterDialog.setCancelable(false)
            alterDialog.create()
            alterDialog.show()
        }

        super.onResume()
    }

}
