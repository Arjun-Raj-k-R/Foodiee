package Activity

import Activity.OrderHistoryActivity
import Fragments.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.drawerlayout.widget.DrawerLayout
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import com.arjun.foddiee.R
import com.google.android.material.navigation.NavigationView


lateinit var drawerlayout:DrawerLayout
lateinit var coordinatorLayout :CoordinatorLayout
lateinit var toolbar: Toolbar   
lateinit var frameLayout: FrameLayout
lateinit var navigationView: NavigationView
lateinit var txtUser: TextView
lateinit var txtNumber: TextView
lateinit var sharedPreferences: SharedPreferences
var previousMenuItem : MenuItem?=null
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sharedPreferences = getSharedPreferences(
                getString(R.string.shared_preferences),
                Context.MODE_PRIVATE
        )
         openhome()

        drawerlayout = findViewById(R.id.drawerLayout)
        coordinatorLayout = findViewById(R.id.coordinatorlayout)
        toolbar = findViewById(R.id.toolbar)
        frameLayout = findViewById(R.id.framelayout)
        navigationView=findViewById(R.id.navigationview)
        val headerView = navigationView.getHeaderView(0)
        txtUser = headerView.findViewById(R.id.txtUser)
        txtNumber = headerView.findViewById(R.id.txtNumber)
        setUpToolbar()
        navigationView.menu.getItem(0).isChecked = true
        txtUser.text = sharedPreferences.getString("name", "UserName")
        txtNumber.text = "+91- ${sharedPreferences.getString("mobile_number", "9999999999")}"
        navigationView.setNavigationItemSelectedListener {
            if (previousMenuItem!=null){
                previousMenuItem?.isChecked = false
            }
            it.isCheckable=true
            it.isChecked=true
            previousMenuItem=it

            when(it.itemId){
                R.id.home ->{
                    openhome()
                }
                R.id.myprofile ->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.framelayout, ProfileFragment(this)
                        ).commit()

                    supportActionBar?.title = "My Profile"
                    drawerlayout.closeDrawers()
                }
                R.id.favouriteResturants ->{
                    supportFragmentManager.beginTransaction()
                            .replace(R.id.framelayout, FavouriteFragment(this))

                            .commit()
                    supportActionBar?.title="Favourites"
                    drawerlayout.closeDrawers( )
                }
                R.id.order_history ->{
                    val intent = Intent(this, OrderHistoryActivity::class.java)
                    drawerlayout.closeDrawers()
                    Toast.makeText(this@MainActivity, "Order History", Toast.LENGTH_SHORT).show()
                    startActivity(intent)
                }
                R.id.faqs ->{
                    supportFragmentManager.beginTransaction()
                        .replace(
                            R.id.framelayout,
                            FAQFragment()
                        ).commit()

                    supportActionBar?.title = "FAQs"
                    drawerlayout.closeDrawers()
                    Toast.makeText(this@MainActivity, "FAQs", Toast.LENGTH_SHORT).show()
                }

                R.id.logout ->{
                    drawerlayout.closeDrawers()

                    val alterDialog = androidx.appcompat.app.AlertDialog.Builder(this)
                    alterDialog.setMessage("Do you wish to log out?")
                    alterDialog.setPositiveButton("Yes") { _, _ ->
                        sharedPreferences.edit().putBoolean("isLoggedIn", false).apply()
                        ActivityCompat.finishAffinity(this)
                    }
                    alterDialog.setNegativeButton("No") { _, _ ->

                    }
                    alterDialog.create()
                    alterDialog.show()

                }


            }
            return@setNavigationItemSelectedListener true
        }
      val actionBarDrawerToggle=ActionBarDrawerToggle(this@MainActivity , drawerlayout, R.string.open_drawer, R.string.close_drawer
      )
        drawerlayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
    }
    override fun onBackPressed() {
        when (supportFragmentManager.findFragmentById(R.id.frameLayout)) {
            !is HomeFragment -> {
                navigationView = findViewById(R.id.navigationView)
                openhome()
            }
            else -> super.onBackPressed()
        }
    }


        fun setUpToolbar(){
            setSupportActionBar(toolbar)
            supportActionBar?.title="Foodie"
            supportActionBar?.setHomeButtonEnabled(true)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)

        }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if(id==android.R.id.home)
        {
            drawerlayout.openDrawer(GravityCompat.START)
        }
        return super.onOptionsItemSelected(item)
    }
    fun openhome(){
        navigationView=findViewById(R.id.navigationview)
        drawerlayout = findViewById(R.id.drawerLayout)
        supportFragmentManager.beginTransaction().replace(R.id.framelayout, HomeFragment(this)).commit()
        supportActionBar?.title = "All Restaurants"
        navigationView.setCheckedItem(R.id.home)
        drawerlayout.closeDrawers()
    }


}