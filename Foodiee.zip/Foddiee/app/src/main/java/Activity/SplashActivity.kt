package Activity

import Activity.MainActivity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.ImageView
import android.widget.TextView
import com.arjun.foddiee.LoginAndRegister
import com.arjun.foddiee.R

lateinit var txtFoodiee: TextView
lateinit var imgAppIcon: ImageView

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        txtFoodiee = findViewById(R.id.txtFoodiee)
        imgAppIcon = findViewById(R.id.imgAppIcon)
        Handler().postDelayed({
            val mainIntent =
                Intent(this@SplashActivity, LoginAndRegister::class.java)
            finish()
            startActivity(mainIntent)
        }, 2000)
    }
}