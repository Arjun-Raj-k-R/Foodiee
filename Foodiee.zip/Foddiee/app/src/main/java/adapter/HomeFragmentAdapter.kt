package adapter

import Activity.RestaurantMenuActivity
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import database.RestaurantDatabase
import database.RestaurantEntity
import com.arjun.foddiee.R
import com.squareup.picasso.Picasso
import model.Restaurant
class HomeFragmentAdapter(val context: Context, var itemList: ArrayList<Restaurant>) :
    RecyclerView.Adapter<HomeFragmentAdapter.ViewHolderDashboard>() {

    class ViewHolderDashboard(view: View) : RecyclerView.ViewHolder(view) {
        val imgRestaurant: ImageView = view.findViewById(R.id.imgRestaurant)
        val txtRestaurantName: TextView = view.findViewById(R.id.txtRestaurantName)
        val txtPrice: TextView = view.findViewById(R.id.txtPrice)
        val txtRating: TextView = view.findViewById(R.id.txtRating)
        val llContent: LinearLayout = view.findViewById(R.id.llContent)
        val txtFavorite: TextView = view.findViewById(R.id.txtFavorite)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderDashboard {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.home_recycler_view_single_row, parent, false)

        return ViewHolderDashboard(view)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    override fun onBindViewHolder(holder: ViewHolderDashboard, position: Int) {

        val restaurant = itemList[position]
        val restaurantEntity = RestaurantEntity(restaurant.restaurantId, restaurant.restaurantName)

        holder.txtRestaurantName.tag = restaurant.restaurantId + ""
        holder.txtRestaurantName.text = restaurant.restaurantName
        holder.txtPrice.text = restaurant.cost_for_one + "/Person"
        holder.txtRating.text = restaurant.restaurantRating

        Picasso.get().load(restaurant.restaurantImage).error(R.drawable.icon)
            .into(holder.imgRestaurant)


        holder.txtFavorite.setOnClickListener {
            if (!DBAsyncTask(context, restaurantEntity, 1).execute().get()) {
                val result = DBAsyncTask(context, restaurantEntity, 2).execute().get()

                if (result) {
                    Toast.makeText(context, "${restaurant.restaurantName} added to Favorites", Toast.LENGTH_SHORT).show()
                    holder.txtFavorite.tag = "liked"
                    holder.txtFavorite.background = context.resources.getDrawable(R.drawable.ic_isfav)

                } else {
                    Toast.makeText(context, "Some error occurred", Toast.LENGTH_SHORT).show()
                }

            } else {
                val result = DBAsyncTask(context, restaurantEntity, 3).execute().get()
                if (result) {

                    Toast.makeText(context, "${restaurant.restaurantName} removed from Favorites", Toast.LENGTH_SHORT).show()
                    holder.txtFavorite.tag = "unliked"
                    holder.txtFavorite.background = context.resources.getDrawable(R.drawable.ic_fav)

                } else {
                    Toast.makeText(context, "Some error occurred", Toast.LENGTH_SHORT).show()
                }
            }
        }

        holder.llContent.setOnClickListener {

            println(holder.txtRestaurantName.tag.toString())
            val intent = Intent(context, RestaurantMenuActivity::class.java)
            intent.putExtra("restaurantId", holder.txtRestaurantName.tag.toString())
            intent.putExtra("restaurantName", holder.txtRestaurantName.text.toString())
            context.startActivity(intent)
        }

        val checkFav = DBAsyncTask(context, restaurantEntity, 1).execute()
        val isFav = checkFav.get()
        if (isFav) {
            holder.txtFavorite.tag = "liked"
            holder.txtFavorite.background = context.resources.getDrawable(R.drawable.ic_isfav)

        } else {
            holder.txtFavorite.tag = "unliked"
            holder.txtFavorite.background = context.resources.getDrawable(R.drawable.ic_fav)
        }
    }

    fun filterList(filteredList: ArrayList<Restaurant>) {
        itemList = filteredList
        notifyDataSetChanged()
    }

    class DBAsyncTask(val context: Context, val restaurantEntity: RestaurantEntity, val mode: Int) :
        AsyncTask<Void, Void, Boolean>() {

        val db =
            Room.databaseBuilder(context, RestaurantDatabase::class.java, "restaurant-db").build()

        override fun doInBackground(vararg p0: Void?): Boolean {


            when (mode) {
                1 -> {
                    val restaurant: RestaurantEntity? = db.restaurantDao()
                        .getRestaurantById(restaurantEntity.restaurantId)
                    db.close()
                    return restaurant != null
                }
                2 -> {
                    db.restaurantDao().insertRestaurant(restaurantEntity)
                    db.close()
                    return true
                }
                3 -> {
                    db.restaurantDao().deleteRestaurant(restaurantEntity)
                    db.close()
                    return true
                }
                else -> return false

            }
        }
    }
}

